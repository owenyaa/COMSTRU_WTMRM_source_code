function y=df(parameter_a)
global N_dof Tdata N_harm N_w0 index
global index_global vector_w
%% 计算两个基频率的组合，注意，频率组合要去掉负数频率
fundamental_w=parameter_a(1,1:N_w0);

for i=1:2:index_global(end,1)
    temp_vector_w((i+1)/2,1)=index_global((i+1)/2,1)*fundamental_w(1,1);
    temp_vector_w((i+1)/2,2:4)=index_global((i+1)/2,1)*fundamental_w(1,1)+fundamental_w(1,2)*index_global((i+1)/2,2:4);
end
size_temp_vector_w=size(temp_vector_w);
vector_w=[];
for i=1:size_temp_vector_w(1,1)
    vector_w=[vector_w;temp_vector_w(i,:)'];
end
Harm_parameter_a=parameter_a(2:end,:);

y_x1_a1=[];y_x2_a1=[];y_dx1_a1=[];y_dx2_a1=[];
y_x1_a2=[];y_x2_a2=[];y_dx1_a2=[];y_dx2_a2=[];
%% 计算谐波系数的灵敏度
for i=1:2*N_harm*N_dof
    sensitivity_parameter_a1=zeros(2*N_harm*N_dof,1);
    x_a=zeros(N_dof,length(Tdata));dx_a=zeros(N_dof,length(Tdata));ddx_a=zeros(N_dof,length(Tdata));
    sensitivity_parameter_a1(i,1)=1;
    sensitivity_parameter_a1=reshape(sensitivity_parameter_a1,2,N_harm*N_dof);sensitivity_parameter_a1=sensitivity_parameter_a1';
    sensitivity_parameter_a=sensitivity_parameter_a1(1:N_harm,1:2);
    for num_dof=1:N_dof-1
        sensitivity_parameter_a=[sensitivity_parameter_a,sensitivity_parameter_a1(num_dof*N_harm+1:(num_dof+1)*N_harm,1:2)];%da(N_harm+1:2*N_harm,1:2);
    end
    for k=1:N_dof
        for j=1:N_harm
            x_a(k,:)=x_a(k,:)+sensitivity_parameter_a(j,2*k-1)*cos(vector_w(j)*Tdata)+sensitivity_parameter_a(j,2*k)*sin(vector_w(j)*Tdata);
            dx_a(k,:)=dx_a(k,:)-vector_w(j)*sensitivity_parameter_a(j,2*k-1)*sin(vector_w(j)*Tdata)+vector_w(j)*sensitivity_parameter_a(j,2*k)*cos(vector_w(j)*Tdata);
            %ddx_a(k,:)=ddx_a(k,:)-(vector_w(j))^2*sensitivity_parameter_a(j,2*k-1)*cos(vector_w(j)*Tdata)-(vector_w(j))^2*sensitivity_parameter_a(j,2*k)*sin(vector_w(j)*Tdata);
        end
    end
    if i<2*N_harm+1
        y_x1_a1=[y_x1_a1,x_a(1,:)'];y_x2_a1=[y_x2_a1,x_a(2,:)'];
        y_dx1_a1=[y_dx1_a1,dx_a(1,:)'];y_dx2_a1=[y_dx2_a1,dx_a(2,:)'];
    else
        y_x1_a2=[y_x1_a2,x_a(1,:)'];y_x2_a2=[y_x2_a2,x_a(2,:)'];
        y_dx1_a2=[y_dx1_a2,dx_a(1,:)'];y_dx2_a2=[y_dx2_a2,dx_a(2,:)'];
    end
end
y_a=[y_x1_a1,y_x1_a2;y_x2_a1,y_x2_a2;y_dx1_a1,y_dx1_a2;y_dx2_a1,y_dx2_a2];
%% 计算频率的灵敏度  只需要计算基频的就可以
%生成数组
for i=1:2:index
    temp_index_global_w1((i+1)/2,1:4)=i;
end
size_temp_w1=size(temp_index_global_w1);
index_global_w1=[];
for i=1:size_temp_w1(1,1)
    index_global_w1=[index_global_w1;temp_index_global_w1(i,:)'];
end
%此处vector_w1为一个列向量
%% 计算频率的灵敏度  只需要计算基频w1的就可以
x_w1=zeros(N_dof,length(Tdata));dx_w1=zeros(N_dof,length(Tdata));ddx_w1=zeros(N_dof,length(Tdata));
for ij=1:N_dof
    for i=1:N_harm   % i=1,3,5
        x_w1(ij,:)=x_w1(ij,:)-index_global_w1(i)*Harm_parameter_a(i,2*ij-1)*Tdata.*sin(vector_w(i)*Tdata)+index_global_w1(i)*Harm_parameter_a(i,2*ij)*Tdata.*cos(vector_w(i)*Tdata);
        dx_w1(ij,:)=dx_w1(ij,:)-(index_global_w1(i)*Harm_parameter_a(i,2*ij-1)*sin(vector_w(i)*Tdata)+vector_w(i)*index_global_w1(i)*Tdata*Harm_parameter_a(i,2*ij-1).*cos(vector_w(i)*Tdata))+...
            (index_global_w1(i)*Harm_parameter_a(i,2*ij)*cos(vector_w(i)*Tdata)-vector_w(i)*index_global_w1(i)*Tdata*Harm_parameter_a(i,2*ij).*sin(vector_w(i)*Tdata));
        %ddx_w1(ij,:)=ddx_w1(ij,:)-(2*vector_w(i)*index_global_w1(i)*Harm_parameter_a(i,2*ij-1)*cos(vector_w(i)*Tdata)-vector_w(i)^2*index_global_w1(i)*Tdata*Harm_parameter_a(i,2*ij-1).*sin(vector_w(i)*Tdata))-...
            %(2*vector_w(i)*index_global_w1(i)*Harm_parameter_a(i,2*ij)*sin(vector_w(i)*Tdata)+vector_w(i)^2*index_global_w1(i)*Tdata*Harm_parameter_a(i,2*ij).*cos(vector_w(i)*Tdata));
    end
end
y_w1=[x_w1(1,:)';x_w1(2,:)';dx_w1(1,:)';dx_w1(2,:)'];
%% 计算频率的灵敏度  只需要计算频宽的就可以
%生成数组
for i=1:2:index
    temp_index_global_wd((i+1)/2,1)=0;
    temp_index_global_wd((i+1)/2,2:4)=[-1,1,2];
end
size_temp_wd=size(temp_index_global_wd);
index_global_wd=[];
for i=1:size_temp_wd(1,1)
    index_global_wd=[index_global_wd;temp_index_global_wd(i,:)'];
end
%此处vector_wd为一个列向量
%% 计算频率的灵敏度  只需要计算频宽wd的就可以
x_wd=zeros(N_dof,length(Tdata));dx_wd=zeros(N_dof,length(Tdata));ddx_wd=zeros(N_dof,length(Tdata));
for ij=1:N_dof
    for i=1:N_harm   % i=1,3,5
        x_wd(ij,:)=x_wd(ij,:)-index_global_wd(i)*Harm_parameter_a(i,2*ij-1)*Tdata.*sin(vector_w(i)*Tdata)+index_global_wd(i)*Harm_parameter_a(i,2*ij)*Tdata.*cos(vector_w(i)*Tdata);
        dx_wd(ij,:)=dx_wd(ij,:)-(index_global_wd(i)*Harm_parameter_a(i,2*ij-1)*sin(vector_w(i)*Tdata)+vector_w(i)*index_global_wd(i)*Tdata*Harm_parameter_a(i,2*ij-1).*cos(vector_w(i)*Tdata))+...
            (index_global_wd(i)*Harm_parameter_a(i,2*ij)*cos(vector_w(i)*Tdata)-vector_w(i)*index_global_wd(i)*Tdata*Harm_parameter_a(i,2*ij).*sin(vector_w(i)*Tdata));
        %ddx_wd(ij,:)=ddx_wd(ij,:)-(2*vector_w(i)*index_global_wd(i)*Harm_parameter_a(i,2*ij-1)*cos(vector_w(i)*Tdata)-vector_w(i)^2*index_global_wd(i)*Tdata*Harm_parameter_a(i,2*ij-1).*sin(vector_w(i)*Tdata))-...
            %(2*vector_w(i)*index_global_wd(i)*Harm_parameter_a(i,2*ij)*sin(vector_w(i)*Tdata)+vector_w(i)^2*index_global_wd(i)*Tdata*Harm_parameter_a(i,2*ij).*cos(vector_w(i)*Tdata));
    end
end
y_wd=[x_wd(1,:)';x_wd(2,:)';dx_wd(1,:)';dx_wd(2,:)'];
y=[y_w1,y_wd,y_a];


end