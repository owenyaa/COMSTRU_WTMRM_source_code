function y=f(num,parameter_a)
global N_dof Tdata N_harm N_w0 %index
global index_global vector_w
%% 计算两个基频率的组合，注意，频率组合要去掉负数频率
fundamental_w=parameter_a(1,1:N_w0);

for i=1:2:index_global(end,1)
    temp_vector_w((i+1)/2,1)=index_global((i+1)/2,1)*fundamental_w(1,1);
    temp_vector_w((i+1)/2,2:4)=index_global((i+1)/2,1)*fundamental_w(1,1)+fundamental_w(1,2)*index_global((i+1)/2,2:4);
end
size_temp_vector_w=size(temp_vector_w);
vector_w=[];
for i=1:size_temp_vector_w(1,1)
    vector_w=[vector_w;temp_vector_w(i,:)'];
end
Harm_parameter_a=parameter_a(2:end,:);
x=zeros(N_dof,length(Tdata));dx=zeros(N_dof,length(Tdata));%ddx=zeros(N_dof,length(Tdata));
% 有三个自由度
for j=1:N_dof
    for i=1:N_harm   % i=1,3,5
        x(j,:)=x(j,:)+Harm_parameter_a(i,2*j-1)*cos(vector_w(i)*Tdata)+Harm_parameter_a(i,2*j)*sin(vector_w(i)*Tdata);
        dx(j,:)=dx(j,:)-vector_w(i)*Harm_parameter_a(i,2*j-1)*sin(vector_w(i)*Tdata)+vector_w(i)*Harm_parameter_a(i,2*j)*cos(vector_w(i)*Tdata);
    end
end
f1=x'-num(:,1:2);
f2=dx'-num(:,3:4);
y=[f1(:,1);f1(:,2);f2(:,1);f2(:,2)];
end