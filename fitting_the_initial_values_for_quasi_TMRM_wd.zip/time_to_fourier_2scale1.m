function y=time_to_fourier_2scale1(w1_input,wd_input,t_input,x_input)%....tt是时间，xx是对于对应的时程，w是预设频率
global index_global

temp=size(t_input);
if temp(1)<=temp(2)
    t_input=t_input';
end
%从index_global恢复为频率，其中temp_vector_w结构和index_global相同，只是从系数变成了频率数值
for i=1:2:index_global(end,1)
    temp_vector_w((i+1)/2,1)=index_global((i+1)/2,1)*w1_input;
    temp_vector_w((i+1)/2,2:4)=index_global((i+1)/2,1)*w1_input+wd_input*index_global((i+1)/2,2:4);
end
size_vector_w=size(temp_vector_w);
%计算组合频率的Jacobi矩阵，Jacobi矩阵的结构为:第一列为cos(w1*t)，第二列为sin(w1*t),第三列为cos((w1-wd)*t)
Jacobi=[];
for i=1:size_vector_w(1,1)
    for j=1:size_vector_w(1,2)
        temp_ww=temp_vector_w(i,j);
        temp_tt=temp_ww*t_input;
        Jacobi=[Jacobi cos(temp_tt) sin(temp_tt)];
    end
end

f_xy_t=x_input;
%计算系数
CS=Jacobi\f_xy_t;
%将正弦和余弦分开,y的结构为一列，从一阶主频开始，再到一阶主频带宽，再到3阶次主频。。。
y=anti_converse1(CS);%.......对应于f_xy_t=(1-xt.^2-yt.^2).^(-n1);的展开式