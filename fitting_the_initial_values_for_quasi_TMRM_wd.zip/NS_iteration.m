%% Author : GUANG_LIU  * owenyaa@gmail.com *
% Created Time : 2020-09-29 17:23
% Last Revised : GUANG_LIU ,2020-09-29
% Remark : 本程序的结构、功能和变量做一下说%
%          本程序主要针对含两个基频的准周期振动响应%
%          本程序的主要功能是从稳的数响(般RK法获)中，拟合出谐波系数%
%          要注意的是，拟合的两个基频会极大地影响拟合的精度，一般需要比较精准的确定%
%          程序的主要部分是子函数time_to_fourier_2scale%
%          主要步骤如下%
%          1.首先通过RK法获得数值解，保存为mat文件%
%          2.创建index_global索引数组，设定组合谐波数n_harm,设定基频w10和w20%
%          3.通过子函数time_to_fourier_2scale拟合出各个自由度的系数，组建parameter_a数组%
%          4.通过拟合系数绘制响应，并和RK法做对比，保存parameter_a数组作为ETMRM初%
clear;close all;clc;
%RK法的数值结果，时间步长0.001，时间200秒
load RK_001_200.mat;

%% 此处通过位移和速度计算加速度
% global A 
% global k13 k14 k15 k16 k23 k24 k25 k26
% global c11 c12 c13 c14 c15 c16 c21 c22 c23 c24 c25 c26
% 
% A1=0.2;A2=0.02;
% b=40*10^(-9);h=20*10^(-9);E=76*10^9;E_s=1.22;L=50*h;
% tau_s=0.570761;
% H_s=2*tau_s*b;E_I=E*b*h^3/12+E_s*h^3/6+E_s*b*h^2/2;
% beta=H_s*L^2/(E_I);mu=2*E_s*(h/b+3)/(E*h);
% 
% 
% k11=12.3596-0.8588*beta+12.3596*mu;k12=0.0068+11.7444*beta+0.0068*mu;k13=-16.3892-2.1571*beta+40.4251*mu;
% k14=1528.0120+41.2266*beta-306.8542*mu;k15=-12783.2313-147.2032*beta+2483.9228*mu;k16=8597.5497+192.7130*beta-2176.2470*mu;
% 
% k21=0.0002-1.8739*beta+0.0002*mu;k22=485.4811+13.2938*beta+485.4811*mu;k23=-57.8499-3.4640*beta-102.2985*mu;
% k24=-872.6730-32.0639*beta+2484.1643*mu;k25=-15292.1786-44.4417*beta-6530.1215*mu;k26=-56843.5188+53.2269*beta+13415.5523*mu;
% 
% c11=4.5968;c12=-3.5964;c13=-7.1928;c14=12.2359;c15=25.1741;c16=-22.1929;
% c21=-3.5963;c22=25.1733;c23=12.2356;c24=-44.3844;c25=22.1922;c26=144.7195;
% 
% M=[1,0;0,1];K=[k11,k12;k21,k22];
% non1=k13*num(:,1).^3+k14*num(:,1).^2.*num(:,2)+k15*num(:,1).*num(:,2).^2+k16*num(:,2).^3+...
%     c11*num(:,1).*num(:,3).^2+c12*num(:,2).*num(:,3).^2+c13*num(:,1).*num(:,3).*num(:,4)+c14*num(:,2).*num(:,3).*num(:,4)+c15*num(:,1).*num(:,4).^2+c16*num(:,2).*num(:,4).^2;
% non2=k23*num(:,1).^3+k24*num(:,1).^2.*num(:,2)+k25*num(:,1).*num(:,2).^2+k26*num(:,2).^3+...
%     c21*num(:,1).*num(:,3).^2+c22*num(:,2).*num(:,3).^2+c23*num(:,1).*num(:,3).*num(:,4)+c24*num(:,2).*num(:,3).*num(:,4)+c25*num(:,1).*num(:,4).^2+c26*num(:,2).*num(:,4).^2;
% ddnum=-M\(K*num(:,1:2)'+[non1,non2]');
% ddnum=ddnum';

global N_dof Tdata N_harm N_w0 index
global index_global vector_w
N_dof=2;N_w0=2;
% Tdata=0:0.001:100;
index=25;
%% 计算基频的组合系index_global=[1,-1,1,2;3,-1,1,2...]
for i=1:2:index
    index_global((i+1)/2,1)=i;
    index_global((i+1)/2,2:4)=[-1,1,2];
end
%% 先拟合出一组NS迭代初值
% w10是主频，w_d是带宽
w10=3.510628883212891;w_d=1.498777127226156;%5.009406010439047;%2.60777;%1.05461;%h=50
h_mat=time_to_fourier_2scale1(w10,w_d,Tdata(1:length(num(:,1))),num(1:length(num(:,1)),1));
alpha_mat=time_to_fourier_2scale1(w10,w_d,Tdata(1:length(num(:,1))),num(1:length(num(:,1)),2));
parameter_a=[h_mat,alpha_mat];parameter_a=[w10,w_d,0,0;parameter_a];
for i=1:2:index_global(end,1)
    temp_vector_w((i+1)/2,1)=index_global((i+1)/2,1)*w10;
    temp_vector_w((i+1)/2,2:4)=index_global((i+1)/2,1)*w10+w_d*index_global((i+1)/2,2:4);
end
size_vector_w=size(temp_vector_w);
vector_w=[];
for i=1:size_vector_w(1,1)
    vector_w=[vector_w;temp_vector_w(i,:)'];
end
%此时，vector_w的频率和h_mat完全对应
N_harm=size_vector_w(1,1)*size_vector_w(1,2);

%% NS迭代出频率和谐波系数
% 当指定频率之后，通过位移可以直接拟合出谐波系数，同样的道理，通过速度和加速度都可以拟合出系数
% 直接拟合的精度，和指定的频率的准确性密切相关
% 为此，可以通过NS迭代，直接精准计算出频率和谐波系数
% 本程序采用的是位移和速度进行NS迭代  其实也可以采用加速度，加速度需要对RK法的结果进一步计算获得
sensitivity_parameter_da=0.1;
while norm(sensitivity_parameter_da)>=1e-8
    dx=-df(parameter_a)\f(num,parameter_a);
    temp_real_w0=zeros(1,2*N_dof);% 参数矩阵的第一行
    temp_real_w0(1,1:N_w0)=dx(1:N_w0,1)';
    temp_real_da=dx(N_w0+1:end,1);
    da=reshape(temp_real_da,2,N_dof*N_harm);da=da';
    sensitivity_parameter_da=da(1:N_harm,1:2);
    for num_dof=1:N_dof-1
        sensitivity_parameter_da=[sensitivity_parameter_da,da(num_dof*N_harm+1:(num_dof+1)*N_harm,1:2)];%da(N_harm+1:2*N_harm,1:2);
    end
    sensitivity_parameter_da=[temp_real_w0;sensitivity_parameter_da];
    
    parameter_a=parameter_a+sensitivity_parameter_da;
    norm(sensitivity_parameter_da)
end



%% 拟合出了频率和谐波系数，计算出位移和加速度
fundamental_w=parameter_a(1,1:N_w0);
Harm_parameter_a=parameter_a(2:end,:);
for i=1:2:index_global(end,1)
    temp_vector_w((i+1)/2,1)=index_global((i+1)/2,1)*fundamental_w(1,1);
    temp_vector_w((i+1)/2,2:4)=index_global((i+1)/2,1)*fundamental_w(1,1)+fundamental_w(1,2)*index_global((i+1)/2,2:4);
end
size_temp_vector_w=size(temp_vector_w);
vector_w=[];
for i=1:size_temp_vector_w(1,1)
    vector_w=[vector_w;temp_vector_w(i,:)'];
end
%此时，vector_w的频率和h_mat完全对应

%% 计算方程残差
x=zeros(N_dof,length(Tdata));dx=zeros(N_dof,length(Tdata));ddx=zeros(N_dof,length(Tdata));
% 有三个自由度
for j=1:N_dof
    for i=1:N_harm   % i=1,3,5
        x(j,:)=x(j,:)+Harm_parameter_a(i,2*j-1)*cos(vector_w(i)*Tdata)+Harm_parameter_a(i,2*j)*sin(vector_w(i)*Tdata);
        dx(j,:)=dx(j,:)-vector_w(i)*Harm_parameter_a(i,2*j-1)*sin(vector_w(i)*Tdata)+vector_w(i)*Harm_parameter_a(i,2*j)*cos(vector_w(i)*Tdata);
        ddx(j,:)=ddx(j,:)-(vector_w(i))^2*Harm_parameter_a(i,2*j-1)*cos(vector_w(i)*Tdata)-(vector_w(i))^2*Harm_parameter_a(i,2*j)*sin(vector_w(i)*Tdata);
    end
end

% figure;
% plot(x(1,:),dx(1,:),'r-','LineWidth',1);
% hold on;
% plot(x(2,:),dx(2,:),'b-','LineWidth',1);
% hold on;
% plot(x(3,:),dx(3,:),'g-','LineWidth',1);
% set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);

%% 此处通过位移和速度计算加速度
global A 
global k13 k14 k15 k16 k23 k24 k25 k26
global c11 c12 c13 c14 c15 c16 c21 c22 c23 c24 c25 c26

A1=0.2;A2=0.02;
b=40*10^(-9);h=20*10^(-9);E=76*10^9;E_s=1.22;L=50*h;
tau_s=0.570761;
H_s=2*tau_s*b;E_I=E*b*h^3/12+E_s*h^3/6+E_s*b*h^2/2;
beta=H_s*L^2/(E_I);mu=2*E_s*(h/b+3)/(E*h);


k11=12.3596-0.8588*beta+12.3596*mu;k12=0.0068+11.7444*beta+0.0068*mu;k13=-16.3892-2.1571*beta+40.4251*mu;
k14=1528.0120+41.2266*beta-306.8542*mu;k15=-12783.2313-147.2032*beta+2483.9228*mu;k16=8597.5497+192.7130*beta-2176.2470*mu;

k21=0.0002-1.8739*beta+0.0002*mu;k22=485.4811+13.2938*beta+485.4811*mu;k23=-57.8499-3.4640*beta-102.2985*mu;
k24=-872.6730-32.0639*beta+2484.1643*mu;k25=-15292.1786-44.4417*beta-6530.1215*mu;k26=-56843.5188+53.2269*beta+13415.5523*mu;

c11=4.5968;c12=-3.5964;c13=-7.1928;c14=12.2359;c15=25.1741;c16=-22.1929;
c21=-3.5963;c22=25.1733;c23=12.2356;c24=-44.3844;c25=22.1922;c26=144.7195;

M=[1,0;0,1];K=[k11,k12;k21,k22];
non1=k13*num(:,1).^3+k14*num(:,1).^2.*num(:,2)+k15*num(:,1).*num(:,2).^2+k16*num(:,2).^3+...
    c11*num(:,1).*num(:,3).^2+c12*num(:,2).*num(:,3).^2+c13*num(:,1).*num(:,3).*num(:,4)+c14*num(:,2).*num(:,3).*num(:,4)+c15*num(:,1).*num(:,4).^2+c16*num(:,2).*num(:,4).^2;
non2=k23*num(:,1).^3+k24*num(:,1).^2.*num(:,2)+k25*num(:,1).*num(:,2).^2+k26*num(:,2).^3+...
    c21*num(:,1).*num(:,3).^2+c22*num(:,2).*num(:,3).^2+c23*num(:,1).*num(:,3).*num(:,4)+c24*num(:,2).*num(:,3).*num(:,4)+c25*num(:,1).*num(:,4).^2+c26*num(:,2).*num(:,4).^2;
ddnum=-M\(K*num(:,1:2)'+[non1,non2]');
ddnum=ddnum';


figure;
plot(Tdata,x(1,:),'b-','LineWidth',1);
hold on;
plot(Tdata,x(2,:),'b-','LineWidth',1);
set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);


hold on
plot(Tdata,num(:,1),'k-');
hold on
plot(Tdata,num(:,2),'k-');
h1=legend('$$x_1$$','$$x_1$$');
set(h1,'Interpreter','latex','FontSize',15);
set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);


% A=[zeros(2),eye(2);-[k11,k12;k21,k22],zeros(2)];
% odex=[0.2;0.02;0;0];
% dt=0.001;
% % Tdata=0:dt:100;
% options=odeset('RelTol',1e-8,'AbsTol',1e-8);
% [t,num]=ode45('odehomo',Tdata,odex,options);

% figure;
% plot(Tdata,ddx(1,:),'b-','LineWidth',1);
% hold on;
% plot(Tdata,ddx(2,:),'b-','LineWidth',1);
% set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);
% h1=legend('$$x_1$$','$$x_1$$');
% set(h1,'Interpreter','latex','FontSize',15);
% set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);
% 
% hold on
% plot(Tdata,ddnum(:,1),'k-');
% hold on
% plot(Tdata,ddnum(:,2),'k-');
% set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);






residua=cal_residual(parameter_a);

figure;
plot(Tdata,residua(:,1),'r-','LineWidth',1);
hold on;
plot(Tdata,residua(:,2),'k-','LineWidth',1);
h1=legend('$$x_1$$','$$x_2$$');
set(h1,'Interpreter','latex','FontSize',15);
set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);




figure;
subplot(2,1,1);
plot(Tdata,x(1,:)'-num(:,1),'r-');
set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);
subplot(2,1,2);
plot(Tdata,x(2,:)'-num(:,2),'b-');
set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);

figure;
plot(Tdata,dx(1,:)'-num(:,3),'k-');
hold on
plot(Tdata,dx(2,:)'-num(:,4),'r-');
set(gca,'FontName','Times New Roman','FontSize',15,'LineWidth',1.5);















